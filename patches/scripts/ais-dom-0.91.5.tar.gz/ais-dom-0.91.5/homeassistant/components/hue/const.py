"""Constants for the Hue component."""
import logging

LOGGER = logging.getLogger('.')
DOMAIN = "hue"
API_NUPNP = 'https://www.meethue.com/api/nupnp'
