"""The discord component."""
