"""The swiss_hydrological_data component."""
