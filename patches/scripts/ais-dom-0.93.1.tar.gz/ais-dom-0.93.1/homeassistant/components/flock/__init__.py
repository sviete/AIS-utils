"""The flock component."""
