"""Constants for the Hue component."""
import logging

LOGGER = logging.getLogger(__package__)
DOMAIN = "hue"
API_NUPNP = 'https://www.meethue.com/api/nupnp'
