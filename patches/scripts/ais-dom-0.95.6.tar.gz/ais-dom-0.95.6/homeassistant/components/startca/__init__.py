"""The startca component."""
