"""The denon component."""
