"""The irish_rail_transport component."""
