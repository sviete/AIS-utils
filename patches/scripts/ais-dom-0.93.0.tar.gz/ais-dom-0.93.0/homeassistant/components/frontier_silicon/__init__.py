"""The frontier_silicon component."""
