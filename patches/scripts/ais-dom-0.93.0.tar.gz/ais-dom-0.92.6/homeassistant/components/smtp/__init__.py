"""The smtp component."""
