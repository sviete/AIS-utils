"""The uptime component."""
