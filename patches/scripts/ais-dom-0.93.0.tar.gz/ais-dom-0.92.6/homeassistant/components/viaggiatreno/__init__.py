"""The viaggiatreno component."""
