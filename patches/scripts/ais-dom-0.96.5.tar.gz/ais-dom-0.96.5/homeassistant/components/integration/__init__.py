"""The integration component."""
