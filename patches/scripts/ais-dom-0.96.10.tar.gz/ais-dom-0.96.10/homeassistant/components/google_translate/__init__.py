"""The google_translate component."""
