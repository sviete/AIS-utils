"""Support for Honeywell (US) Total Connect Comfort climate systems."""
