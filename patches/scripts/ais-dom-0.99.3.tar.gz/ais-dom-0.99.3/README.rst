AIS Home Assistant
=================================================================================

home automation platform able to track and control all devices at home and offer a control by voice and automating the control.

To get started:

.. code:: bash

    python3 -m pip install ais-dom
    hass --open-ui

|screenshot-states|


.. |screenshot-states| image:: https://raw.github.com/sviete/AIS-home-assistant/master/docs/screenshots.png
   :target: https://ai-speaker.com
