"""The Aurora ABB Powerone PV inverter sensor integration."""
