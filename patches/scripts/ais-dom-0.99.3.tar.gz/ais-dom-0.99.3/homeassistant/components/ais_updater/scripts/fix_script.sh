#!/data/data/pl.sviete.dom/files/usr/bin/sh
echo START
touch ~/AIS/hej_andrzej.txt
echo STOP
