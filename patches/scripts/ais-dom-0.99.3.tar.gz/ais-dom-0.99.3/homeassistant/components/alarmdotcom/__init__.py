"""The alarmdotcom component."""
