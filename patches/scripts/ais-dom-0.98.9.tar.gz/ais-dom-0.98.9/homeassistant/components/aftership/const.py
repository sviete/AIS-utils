"""Constants for the Aftership integration."""
DOMAIN = "aftership"
