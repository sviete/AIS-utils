"""Const for Geofency."""

DOMAIN = "geofency"
