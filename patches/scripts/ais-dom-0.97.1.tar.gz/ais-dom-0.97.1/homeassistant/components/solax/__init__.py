"""The solax component."""
