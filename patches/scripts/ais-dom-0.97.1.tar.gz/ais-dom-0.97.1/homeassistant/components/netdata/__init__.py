"""The netdata component."""
