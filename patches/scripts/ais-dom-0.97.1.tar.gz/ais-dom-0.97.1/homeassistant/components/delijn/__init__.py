"""The delijn component."""
