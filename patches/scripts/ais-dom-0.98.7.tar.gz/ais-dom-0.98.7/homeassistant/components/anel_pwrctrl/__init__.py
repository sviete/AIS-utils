"""The anel_pwrctrl component."""
