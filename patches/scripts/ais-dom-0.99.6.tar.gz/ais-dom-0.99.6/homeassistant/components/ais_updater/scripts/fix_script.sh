#!/bin/sh
echo "2019-10-12 08:36:37" > /data/data/pl.sviete.dom/files/home/AIS/.ais_fix
