#!/bin/sh
apt update 
apt upgrade -y 
echo "19.10.09" > /data/data/pl.sviete.dom/files/home/AIS/.ais_apt
