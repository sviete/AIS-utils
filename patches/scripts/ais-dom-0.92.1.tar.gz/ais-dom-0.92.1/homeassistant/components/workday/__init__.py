"""Sensor to indicate whether the current day is a workday."""
