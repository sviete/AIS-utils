"""The rejseplanen component."""
