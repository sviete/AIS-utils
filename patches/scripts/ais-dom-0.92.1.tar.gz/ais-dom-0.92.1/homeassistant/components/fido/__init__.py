"""The fido component."""
