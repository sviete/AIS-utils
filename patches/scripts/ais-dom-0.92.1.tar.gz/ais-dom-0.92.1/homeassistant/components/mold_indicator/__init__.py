"""Calculates mold growth indication from temperature and humidity."""
