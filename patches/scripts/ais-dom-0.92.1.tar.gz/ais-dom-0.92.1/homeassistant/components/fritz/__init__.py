"""The fritz component."""
