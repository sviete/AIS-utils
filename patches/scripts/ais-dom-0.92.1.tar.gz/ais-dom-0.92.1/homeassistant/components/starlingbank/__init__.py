"""The starlingbank component."""
