"""The seven_segments component."""
