"""The switchbot component."""
