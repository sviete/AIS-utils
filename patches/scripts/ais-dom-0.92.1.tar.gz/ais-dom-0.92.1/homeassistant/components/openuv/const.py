"""Define constants for the OpenUV component."""
DOMAIN = 'openuv'
