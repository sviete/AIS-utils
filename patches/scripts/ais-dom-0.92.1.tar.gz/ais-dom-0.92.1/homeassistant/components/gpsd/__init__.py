"""The gpsd component."""
