"""The synology_chat component."""
