"""The greenwave component."""
