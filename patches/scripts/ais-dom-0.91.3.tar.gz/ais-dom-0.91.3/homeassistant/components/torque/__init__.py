"""The torque component."""
