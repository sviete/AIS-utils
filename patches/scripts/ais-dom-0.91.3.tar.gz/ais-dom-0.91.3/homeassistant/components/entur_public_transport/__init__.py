"""Component for integrating entur public transport."""
