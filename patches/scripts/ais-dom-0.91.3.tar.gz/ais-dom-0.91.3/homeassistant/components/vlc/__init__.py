"""The vlc component."""
