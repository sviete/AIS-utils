"""Support for Honeywell Round Connected and Honeywell Evohome thermostats."""
