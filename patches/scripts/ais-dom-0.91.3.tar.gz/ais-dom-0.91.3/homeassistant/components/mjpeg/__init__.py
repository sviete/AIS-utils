"""The mjpeg component."""
