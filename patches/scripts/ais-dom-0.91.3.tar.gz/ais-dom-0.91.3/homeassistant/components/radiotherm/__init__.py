"""The radiotherm component."""
