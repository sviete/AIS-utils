"""The bt_home_hub_5 component."""
