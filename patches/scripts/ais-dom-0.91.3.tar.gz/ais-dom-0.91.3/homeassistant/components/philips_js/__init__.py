"""The philips_js component."""
