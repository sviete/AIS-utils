"""Constants for the ais host name."""
DOMAIN = 'ais_spotify_service'
