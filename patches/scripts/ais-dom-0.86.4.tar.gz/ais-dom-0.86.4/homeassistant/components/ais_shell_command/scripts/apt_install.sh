#!/data/data/pl.sviete.dom/files/usr/bin/sh
apt update