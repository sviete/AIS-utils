"""The glances component."""
