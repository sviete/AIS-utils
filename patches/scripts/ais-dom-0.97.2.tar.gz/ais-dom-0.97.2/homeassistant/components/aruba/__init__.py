"""The aruba component."""
