"""The prezzibenzina component."""
