"""The sigfox component."""
