"""The dwd_weather_warnings component."""
