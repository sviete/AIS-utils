"""The universal component."""
