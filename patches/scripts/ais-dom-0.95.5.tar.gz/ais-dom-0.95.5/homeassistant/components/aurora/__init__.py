"""The aurora component."""
