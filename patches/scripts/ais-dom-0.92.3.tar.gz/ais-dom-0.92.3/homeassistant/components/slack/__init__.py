"""The slack component."""
