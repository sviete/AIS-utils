"""The yamaha_musiccast component."""
