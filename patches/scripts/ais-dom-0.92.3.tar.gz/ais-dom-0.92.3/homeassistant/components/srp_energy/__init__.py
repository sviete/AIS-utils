"""The srp_energy component."""
