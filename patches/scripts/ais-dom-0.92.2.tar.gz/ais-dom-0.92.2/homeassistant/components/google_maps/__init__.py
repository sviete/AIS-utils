"""The google_maps component."""
