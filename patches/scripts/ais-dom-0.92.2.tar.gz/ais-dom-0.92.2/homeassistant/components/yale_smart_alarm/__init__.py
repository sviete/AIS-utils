"""The yale_smart_alarm component."""
