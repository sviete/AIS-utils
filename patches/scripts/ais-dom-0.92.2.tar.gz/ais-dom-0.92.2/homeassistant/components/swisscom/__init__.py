"""The swisscom component."""
