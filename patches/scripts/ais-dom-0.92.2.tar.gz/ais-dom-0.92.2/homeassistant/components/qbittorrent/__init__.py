"""The qbittorrent component."""
