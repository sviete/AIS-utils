"""The rpi_gpio_pwm component."""
