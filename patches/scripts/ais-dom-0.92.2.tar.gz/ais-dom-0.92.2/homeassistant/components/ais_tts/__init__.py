"""Set up the demo environment that mimics interaction with devices."""
