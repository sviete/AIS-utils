"""Hass.io const variables."""

ATTR_DISCOVERY = 'discovery'
ATTR_ADDON = 'addon'
ATTR_NAME = 'name'
ATTR_SERVICE = 'service'
ATTR_CONFIG = 'config'
ATTR_UUID = 'uuid'
ATTR_USERNAME = 'username'
ATTR_PASSWORD = 'password'

X_HASSIO = 'X-Hassio-Key'
X_INGRESS_PATH = "X-Ingress-Path"
X_HASS_USER_ID = 'X-Hass-User-ID'
X_HASS_IS_ADMIN = 'X-Hass-Is-Admin'
