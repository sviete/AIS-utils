"""The pulseaudio_loopback component."""
