"""The yr component."""
