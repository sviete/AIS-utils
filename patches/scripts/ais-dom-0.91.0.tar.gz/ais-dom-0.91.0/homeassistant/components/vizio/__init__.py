"""The vizio component."""
