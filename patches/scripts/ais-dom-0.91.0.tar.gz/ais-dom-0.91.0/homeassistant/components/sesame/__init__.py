"""The sesame component."""
