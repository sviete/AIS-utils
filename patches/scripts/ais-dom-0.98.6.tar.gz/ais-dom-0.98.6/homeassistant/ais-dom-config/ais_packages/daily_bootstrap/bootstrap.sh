echo "all up to date!"
# apt update
# apt install -y libxml2
# apt install -y libxslt
# apt install -y libxml2-dev
# apt install -y libxslt-dev
pip install homeassistant==0.69.1
# todo update android app and restart
