"""The asterisk_cdr component."""
