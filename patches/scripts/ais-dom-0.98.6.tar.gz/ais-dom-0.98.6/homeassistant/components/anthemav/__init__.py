"""The anthemav component."""
