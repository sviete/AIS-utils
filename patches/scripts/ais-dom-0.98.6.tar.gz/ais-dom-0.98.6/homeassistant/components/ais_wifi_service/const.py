"""Constants for the ais host name."""
DOMAIN = 'ais_wifi_service'
