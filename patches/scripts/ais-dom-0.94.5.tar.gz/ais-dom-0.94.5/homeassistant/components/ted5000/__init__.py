"""The ted5000 component."""
