"""The solaredge component."""
