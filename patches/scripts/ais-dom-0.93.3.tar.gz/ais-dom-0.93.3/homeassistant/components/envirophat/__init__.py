"""The envirophat component."""
