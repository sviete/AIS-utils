"""The mitemp_bt component."""
