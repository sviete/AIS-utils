"""The prowl component."""
