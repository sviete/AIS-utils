"""Const for Mailgun."""

DOMAIN = "mailgun"
