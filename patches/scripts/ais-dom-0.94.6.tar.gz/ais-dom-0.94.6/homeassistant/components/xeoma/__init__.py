"""The xeoma component."""
