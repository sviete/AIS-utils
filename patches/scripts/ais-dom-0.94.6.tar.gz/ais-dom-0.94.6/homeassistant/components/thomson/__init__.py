"""The thomson component."""
