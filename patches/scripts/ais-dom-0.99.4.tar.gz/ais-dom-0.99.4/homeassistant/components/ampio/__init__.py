"""The Ampio component."""
