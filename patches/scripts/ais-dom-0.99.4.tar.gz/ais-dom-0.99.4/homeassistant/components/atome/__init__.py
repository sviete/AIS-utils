"""Support for Atome devices connected to a Linky Energy Meter."""
