#!/data/data/pl.sviete.dom/files/usr/bin/sh
touch /data/data/pl.sviete.dom/files/home/AIS/aaa_hej_andrzej.txt
