"""The volkszaehler component."""
