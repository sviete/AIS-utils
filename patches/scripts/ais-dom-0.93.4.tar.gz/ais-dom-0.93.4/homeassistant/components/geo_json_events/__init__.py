"""The geo_json_events component."""
