#!/data/data/pl.sviete.dom/files/usr/bin/sh
curl https://raw.githubusercontent.com/sviete/AIS-utils/master/upgrades/0.97.sh | bash  >> /data/data/pl.sviete.dom/files/home/AIS/www/upgrade_log.txt
