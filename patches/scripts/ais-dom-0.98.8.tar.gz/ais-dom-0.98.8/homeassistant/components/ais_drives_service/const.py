"""Constants for the ais host name."""
DOMAIN = 'ais_drives_service'
