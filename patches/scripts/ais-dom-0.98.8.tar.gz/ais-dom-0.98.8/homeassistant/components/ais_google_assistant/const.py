"""Constants for the ais host name."""
DOMAIN = 'ais_google_assistant'
