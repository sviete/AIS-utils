"""The avea component."""
