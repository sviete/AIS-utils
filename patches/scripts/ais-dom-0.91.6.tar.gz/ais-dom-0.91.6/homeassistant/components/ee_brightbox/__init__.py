"""The ee_brightbox component."""
