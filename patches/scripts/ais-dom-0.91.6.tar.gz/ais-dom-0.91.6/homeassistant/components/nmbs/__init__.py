"""The nmbs component."""
