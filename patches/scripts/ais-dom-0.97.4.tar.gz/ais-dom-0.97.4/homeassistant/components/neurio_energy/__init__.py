"""The neurio_energy component."""
