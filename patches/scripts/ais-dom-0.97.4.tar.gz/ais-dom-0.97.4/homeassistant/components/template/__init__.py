"""The template component."""
