"""The dte_energy_bridge component."""
