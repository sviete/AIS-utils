"""The sql component."""
