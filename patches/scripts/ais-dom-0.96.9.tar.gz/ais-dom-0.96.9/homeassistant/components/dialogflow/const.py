"""Const for DialogFlow."""

DOMAIN = "dialogflow"
