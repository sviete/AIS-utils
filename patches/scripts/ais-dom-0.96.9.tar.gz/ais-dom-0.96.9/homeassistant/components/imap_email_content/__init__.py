"""The imap_email_content component."""
