"""The history_stats component."""
