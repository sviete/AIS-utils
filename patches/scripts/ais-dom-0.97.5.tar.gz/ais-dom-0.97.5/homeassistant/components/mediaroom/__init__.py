"""The mediaroom component."""
