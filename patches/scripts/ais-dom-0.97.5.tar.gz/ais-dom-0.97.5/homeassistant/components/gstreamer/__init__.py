"""The gstreamer component."""
