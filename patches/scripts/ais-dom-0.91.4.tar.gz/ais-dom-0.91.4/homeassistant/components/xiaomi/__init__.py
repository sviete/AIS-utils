"""The xiaomi component."""
