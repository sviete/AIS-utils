"""The rocketchat component."""
