"""The nanoleaf component."""
