"""The dnsip component."""
