"""The trafikverket_weatherstation component."""
