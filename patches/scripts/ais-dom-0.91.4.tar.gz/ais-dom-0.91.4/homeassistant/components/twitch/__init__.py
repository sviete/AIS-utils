"""The twitch component."""
