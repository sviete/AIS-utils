"""The samsungtv component."""
