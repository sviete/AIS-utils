"""The directv component."""
