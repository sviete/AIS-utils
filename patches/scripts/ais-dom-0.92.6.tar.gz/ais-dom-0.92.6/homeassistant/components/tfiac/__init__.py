"""The tfiac component."""
