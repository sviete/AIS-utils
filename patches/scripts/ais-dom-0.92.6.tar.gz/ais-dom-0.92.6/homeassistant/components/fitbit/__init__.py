"""The fitbit component."""
