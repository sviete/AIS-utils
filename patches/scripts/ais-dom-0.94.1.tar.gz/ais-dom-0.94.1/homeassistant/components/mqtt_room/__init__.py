"""The mqtt_room component."""
