"""The vasttrafik component."""
