"""The nzbget component."""
