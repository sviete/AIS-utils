"""The generic_thermostat component."""
