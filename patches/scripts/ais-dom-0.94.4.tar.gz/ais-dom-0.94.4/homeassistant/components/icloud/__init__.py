"""The icloud component."""
